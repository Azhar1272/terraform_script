import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from py4j.java_gateway import java_import
import boto3
from botocore.exceptions import ClientError
import json
from typing import Optional, List, Dict, Union, Any


def capture_args(
        arg_names: Optional[List[str]] = ["JOB_NAME", "S3_OUTPUT_PATH", "TABLE_NAME", "JDBC_SECRET_NAME", "PRIME_BUCKET", "PRIME_PREFIX" ]
) -> Optional[Dict[str, str]]:
    """
    Captures the Glue arguments using the getResolvedOptions method.

    Args:
        arg_names (List[str], optional): A list of argument names to capture. Defaults to ['s3_output_path', 'table_name', 'jdbc_secret_name', 'PRIME_BUCKET', 'PRIME_PREFIX'].

    Returns:
        Dict[str, str]: A dictionary containing the captured argument values.
    """
    return getResolvedOptions(sys.argv, arg_names) if arg_names is not None else None


def get_secret(
        secret_name: str,
        placeholder: Optional[Union[str, bytes]] = None,
        raise_on_error: bool = True,
        json_output: bool = False,
) -> Optional[Any]:
    """
    Retrieve the secret value from AWS Secrets Manager.

    Args:
        secret_name (str): The name of the secret to retrieve.
        placeholder (Optional[Union[str, bytes]], optional): The value to return if the secret doesn't exist and raise_on_error is False. Defaults to None.
        raise_on_error (bool, optional): If True, raises an exception when the secret doesn't exist or is deleted. If False, returns the placeholder value. Defaults to True.
        json_output (bool, optional): If True, returns the secret value using json.loads(). If False, returns the secret value as a string or bytes. Defaults to True.

    Returns:
        Optional[Any]: The secret value, the placeholder value if raise_on_error is False and the secret doesn't exist, or the parsed JSON object if json_output is True.
    """
    client = boto3.client("secretsmanager")

    try:
        response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        if raise_on_error:
            raise e
        else:
            return placeholder

    if "SecretString" in response:
        secret_value = response["SecretString"]
    else:
        secret_value = response["SecretBinary"].decode("utf-8")

    if json_output:
        return json.loads(secret_value)
    else:
        return secret_value


def get_all_prefixes(
        prime_bucket: str,
        prime_prefix: str,
        raise_on_error: bool = True,
) -> Optional[List[str]]:
    """
    Retrieve the prefix list from AWS S3 Bucket.

    Args:
        raise_on_error (bool, optional): If True, raises an exception when the prefix doesn't exist or is deleted.Defaults to True.

    Returns:
        Optional[List[str]]: The prefix list values, raise exception if raise_on_error is True
    """

    client = boto3.client('s3')

    try:
        result = client.list_objects(Bucket=prime_bucket, Prefix=prime_prefix, Delimiter='/')
    except ClientError as e:
        if raise_on_error:
            raise e

    all_prefixes = [o.get('Prefix') for o in result.get('CommonPrefixes')]

    return all_prefixes