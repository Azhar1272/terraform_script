import sys
import boto3
from botocore.exceptions import ClientError
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from typing import Optional, List, Dict


def capture_args(
        arg_names: Optional[List[str]] = ["JOB_NAME", "filesize_mb", "S3_PREFIX", "PRIME_BUCKET", "PRIME_PREFIX"]
) -> Optional[Dict[str, str]]:
    """
    Captures the Glue arguments using the getResolvedOptions method.

    Args:
        arg_names (List[str], optional): A list of argument names to capture. Defaults to ['filesize_mb', 'S3_PREFIX', 'PRIME_BUCKET', 'PRIME_PREFIX'].

    Returns:
        Dict[str, str]: A dictionary containing the captured argument values.
    """
    return getResolvedOptions(sys.argv, arg_names) if arg_names is not None else None


def get_datasize(
        prime_bucket: str,
        prime_prefix:str,
        s3_key: str,
        raise_on_error: bool = True,
) -> int:
    s3 = boto3.resource('s3')
    try:
        my_bucket = s3.Bucket(prime_bucket)
    except ClientError as e:
        if raise_on_error:
            raise e
    total_size = 0
    for obj in my_bucket.objects.filter(Prefix=f"{prime_prefix}{s3_key}"):
        total_size = total_size + obj.size
    return total_size


def get_all_prefixes(
        prime_bucket: str,
        prime_prefix: str,
        raise_on_error: bool = True,
) -> Optional[List[str]]:
    """
    Retrieve the prefix list from AWS S3 Bucket.

    Args:
        raise_on_error (bool, optional): If True, raises an exception when the prefix doesn't exist or is deleted.Defaults to True.

    Returns:
        Optional[List[str]]: The prefix list values, raise exception if raise_on_error is True
    """

    client = boto3.client('s3')

    try:
        result = client.list_objects(Bucket=prime_bucket, Prefix=prime_prefix, Delimiter='/')
    except ClientError as e:
        if raise_on_error:
            raise e

    all_prefixes = [o.get('Prefix') for o in result.get('CommonPrefixes')]

    return all_prefixes

